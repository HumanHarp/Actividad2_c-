#include <iostream>
#include <fstream>
#include <string>
#include <chrono>

void remove_html_tags(const std::string& input_filename) {
    std::ifstream input_file(input_filename);
    if (!input_file.is_open()) {
        std::cerr << "Error al abrir el archivo de entrada: " << input_filename << std::endl;
        return;
    }

    std::string output_filename = "cleaned_" + input_filename;
    std::ofstream output_file(output_filename);
    if (!output_file.is_open()) {
        std::cerr << "Error al abrir el archivo de salida: " << output_filename << std::endl;
        return;
    }

    bool in_tag = false;
    char ch;
    while (input_file.get(ch)) {
        if (ch == '<') {
            in_tag = true;
        } else if (ch == '>') {
            in_tag = false;
        } else if (!in_tag) {
            output_file << ch;
        }
    }

    input_file.close();
    output_file.close();
}

int main() {
    auto start = std::chrono::high_resolution_clock::now();

    std::string input_filename = "002.html";    
    remove_html_tags(input_filename);

    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed = end - start;

    std::ofstream log_file("a2_matricula.txt", std::ios::app);
    if (log_file.is_open()) {
        log_file << "Tiempo de ejecución para eliminar etiquetas en " << input_filename << ": " 
                 << elapsed.count() << " segundos" << std::endl;
        log_file.close();
    } else {
        std::cerr << "Error al abrir el archivo de log" << std::endl;
    }

    return 0;
}
